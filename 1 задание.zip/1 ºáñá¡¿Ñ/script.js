// Функция для расчета по формуле
function calculateFormula(a, b, c) {
    try {
        var π = Math.PI;
        
        // Вычисление выражения под корнем
        var expressionUnderRoot = (c + 2 * π) / Math.abs(b - Math.abs(c) - 7 * (a * a - π));
        
        // Проверка на отрицательное значение под корнем
        if (expressionUnderRoot < 0) {
            throw new Error("Нельзя извлекать квадратный корень из отрицательного числа.");
        }
        
        // Вычисление корня из выражения
        var result = Math.sqrt(expressionUnderRoot);
        
        // Проверка на деление на ноль
        if (isNaN(result)) {
            throw new Error("Ошибка вычисления: деление на ноль.");
        }
        
        // Возвращаем результат расчета
        return result;
        
    } catch (error) {
        // Обработка исключительных ситуаций
        alert("Ошибка: " + error.message);
        return null; // Возвращаем null в случае ошибки
    }
}
